var appStatus = false;
var appVibrate = false;
var off = true;
var starting = true;
( function () {

	window.addEventListener( 'tizenhwkey', function( ev ) {
		if( ev.keyName == "back" ) {
			var page = document.getElementsByClassName( 'ui-page-active' )[0],
				pageid = page ? page.id : "";
			if( pageid === "main" ) {
				try {
					if (appStatus){
						//window.webapis.motion.stop("HRM");
						tizen.application.getCurrentApplication().hide();
					}else{
						tizen.power.release("CPU");
						tizen.power.release("SCREEN");
						
						tizen.application.getCurrentApplication().exit();
					}
				} catch (ignore) {
				}
			} else {
				window.history.back();
			}
		}
	} );
} () );

function onScreenStateChanged(previousState, changedState){
	if (changedState != "SCREEN_BRIGHT" || !tizen.power.isScreenOn()){
		  var d = new Date();
		  var h = d.getHours();
		  var m = d.getMinutes();
//		tizen.power.turnScreenOn();
//		tizen.power.setScreenBrightness(0.1);
		  console.log("here");
		  console.log(m);
		if(starting == true || (m % 30 == 0)){
			 console.log("on");
			tizen.power.request("CPU", "CPU_AWAKE");
			tizen.power.request("SCREEN", "SCREEN_NORMAL");
			starting = false
		}
	}else if (tizen.power.isScreenOn()){
		tizen.power.release("SCREEN");
	}
}


//add code
function gyroOnchangedCB(sensorData) {
//console.log("ffff");
//console.log(sensorData.x.toFixed(5));
//var gyroLog = "x: " + sensorData.x.toFixed(5) +"," + "y: " + sensorData.y.toFixed(5) + "," + "z: " + sensorData.z.toFixed(5) +  "x drift: " + sensorData.xAxisDrift.toFixed(5) +"," + "y drift: " + sensorData.yAxisDrift.toFixed(5) + "," + "z drift: " + sensorData.zAxisDrift.toFixed(5) + "- \n";
var gyroLog = "x: " + sensorData.x.toFixed(5) +"," + "y: " + sensorData.y.toFixed(5) + "," + "z: " + sensorData.z.toFixed(5)  + "- \n" + gyroSensorCount;
gyroSensorText = gyroSensorText + gyroLog;
gyroSensorCount++;
if(gyroSensorCount % 60){
//	AppendDoc(gyroscopeFileName, gyroSensorText);
//	gyroSensorText = "";
}

}

function gyroOnsuccessCB() {
    console.log("GYROSCOPE Sensor start");


}
function OnsuccessCB() {
    console.log("linear start");
}

function laccOnchangedCB(sensorData) {
//	console.log("dddd");
//	console.log(sensorData.x.toFixed(8));
	laccSensorCount++;
	var lacc = "x: " + sensorData.x.toFixed(5) +"," + "y: " + sensorData.y.toFixed(5) + "," + "z: " + sensorData.z.toFixed(5) + "- \n" + laccSensorCount;
	laccSensorText = laccSensorText + lacc;
	if(laccSensorCount % 30 == 0){
//		AppendDoc(linear_accelerationFileName, laccSensorText);
//		laccSensorText = "";
	}
	
}


function gravOnsuccessCB() {
    console.log("GRAVITY Sensor start");
 
}

function gravOnchangedCB(sensorData) {
//	console.log("bbbb");
//	console.log(sensorData.x.toFixed(5));
	var gravityLog =  "x: " + sensorData.x.toFixed(5) +"," + "y: " + sensorData.y.toFixed(5) + "," + "z: " + sensorData.z.toFixed(5) + "- \n" + gravSensorCount;
	gravSensorText = gravSensorText + gravityLog;
	gravSensorCount++;
	if(gravSensorCount % 40 == 0){
//		AppendDoc(gravityFileName, gravSensorText);
//		gravSensorText = "";
	}
	
}

function hrsuccess() {
    console.log("zzzzz");
 
}

function hrOnchanged(sensorData) {
//	console.log("nnnn");
//	console.log(sensorData.lightIntensity);
	hrCount++;
	if(sensorData.lightIntensity == null){
		console.log("ggggggqq");
	}
	else if(sensorData.lightIntensity == "undefined"){
		console.log("nnnnn333");
	}
	else if(sensorData.lightIntensity.toString().length > 0){
		  var d = new Date();
		  var h = d.getHours();
		  var m = d.getMinutes();
//		console.log(sensorData.lightIntensity);
		hrLog = "index" + ":" + " " + hrCount + "-" + "time: " + h + ":" +m + "-"  + sensorData.lightIntensity.toString() + "- \n" ;
		hrText = hrText + hrLog;
//		console.log("lennn: " + hrText.length);
	}else{
		console.log("bbbbbqqqq");
//		console.log(sensorData.lightIntensity);
	}

	if(hrCount % 200 == 0){
		AppendDoc(hrmFileName, hrText);
		hrText = "";
	}
	
}

//add code
//var gyroSensor = tizen.sensorservice.getDefaultSensor('GYROSCOPE');
//var gravSensor = tizen.sensorservice.getDefaultSensor('GRAVITY');
//var accSensor = tizen.sensorservice.getDefaultSensor('ACCELERATION');
//var laccSensor = tizen.sensorservice.getDefaultSensor('LINEAR_ACCELERATION');
var hr = tizen.sensorservice.getDefaultSensor('HRM_RAW');

var gyroSensorText = "";
var gravSensorText = "";
var accSensorText = "";
var laccSensorText = "";
var hrText = "";
var heartRateText = "";

var gyroSensorCount =0;
var gravSensorCount =0;
var accSensorCount =0;
var laccSensorCount =0;
var hrCount =0;
var heartRateCount =0;
//add code

var start;
//window.webapis.motion.start("HRM", onchangedCB);
var lblHR = document.getElementById("htmlHR");
//var lblHRV = document.getElementById("htmlHRV");

tizen.power.request("CPU", "CPU_AWAKE");
tizen.power.request("SCREEN", "SCREEN_NORMAL");

tizen.power.setScreenStateChangeListener(onScreenStateChanged);

function btnStart_Click(){

	appStatus = true;
	window.webapis.motion.start("HRM", onchangedCB,1000);
	// add code
//    gyroSensor.start(gyroOnsuccessCB);
//    gyroSensor.setChangeListener(gyroOnchangedCB, 1000);
//    gravSensor.start(gravOnsuccessCB);
//	gravSensor.setChangeListener(gravOnchangedCB, 1000);
//	laccSensor.start(OnsuccessCB);
//    laccSensor.setChangeListener(laccOnchangedCB, 1000);
	hr.start(hrsuccess);
	hr.setChangeListener(hrOnchanged, 1000);
//    accSensor.start(OnsuccessCB);
//    accSensor.setChangeListener(accOnchangedCB, 1000);
     

    // add code
	start = +new Date();
	lblHR.innerHTML = "Initializing...";
	var btnStart = document.getElementById("btnStart");
	var btnStop = document.getElementById("btnStop");

	btnStart.setAttribute("disabled", "disabled");
	btnStop.removeAttribute("disabled");
	   var d = new Date();
	   var n = d.getTime();
	if (currentFileName.length < 4){
		currentFileName = "HeartRate_" + n + ".txt";
		NewDoc(currentFileName);
	}
//	if (gyroscopeFileName.length < 4){
//		gyroscopeFileName = "gyroscope_" + n + ".txt";
//		NewDoc(gyroscopeFileName);
//	}
//	if (gravityFileName.length < 4){
//		gravityFileName = "gravity_" + n + ".txt";
//		NewDoc(gravityFileName);
//	}
//	if (linear_accelerationFileName.length < 4){
//		linear_accelerationFileName = "linear_acceleration_" + n + ".txt";
//		NewDoc(linear_accelerationFileName);
//	}
	if (hrmFileName.length < 4){
		hrmFileName = "hrm_" + n + ".txt";
		NewDoc(hrmFileName);
	}
	
}


function hasStress_Click(){
	  var d = new Date();
	  var h = d.getHours();
	  var m = d.getMinutes();
	  
	
	
}




function btnStop_Click(){
	appStatus = false;
	window.webapis.motion.stop("HRM");
	hr.stop();
//	laccSensor.stop();
//	gravSensor.stop();
//	gyroSensor.stop();
	
//	console.log(gyroSensorCount);
//	console.log(gravSensorCount);
//	console.log(laccSensorCount);
	console.log(hrCount);
//	console.log(hrText.length);
	console.log(heartRateCount);
	AppendDoc(currentFileName, heartRateText);
	AppendDoc(hrmFileName, hrText);
//	AppendDoc(linear_accelerationFileName, laccSensorText)
//	AppendDoc(gravityFileName, gravSensorText);
//	AppendDoc(gyroscopeFileName, gyroSensorText);
	var btnStart = document.getElementById("btnStart");
	var btnStop = document.getElementById("btnStop");

	btnStop.setAttribute("disabled", "disabled");
	btnStart.removeAttribute("disabled");
}

function onchangedCB(hrmInfo) 
{
	  var d = new Date();
	  var h = d.getHours();
	  var m = d.getMinutes();
	if(off == true){
		tizen.power.release("SCREEN");
		off = false;
	}
	var log;
	var end = +new Date();
	var timestamp = end - start; 
   if(hrmInfo.heartRate > 0 && hrmInfo.rRInterval > 0) {
	   appVibrate = false;
	  
//	   log = timestamp + "," + hrmInfo.heartRate + "," + hrmInfo.rRInterval + "," + Math.round(60000 / hrmInfo.heartRate);
	   lblHR.innerHTML = "HR: " + hrmInfo.heartRate + " bpm";
//	   lblHRV.innerHTML = "HRV: " + hrmInfo.rRInterval + " ms";
	   log = "index" + ":" + " " + heartRateCount + "-" + "time: " + h+":"+m + "-" +": " + "heartRate:" + hrmInfo.heartRate + "-" + "heartInterval:" + hrmInfo.rRInterval +"\n" ;
	   heartRateText = heartRateText + log ;
	   heartRateCount++;
	   if(heartRateCount % 150 == 0){
		   console.log("write hr to file");
		   AppendDoc(currentFileName, heartRateText);
		   heartRateText = "";
	   }
	  
   } else if ((hrmInfo.heartRate <= 0) && (m % 10 == 0)){
	   tizen.application.launch("Acs0pDEG2v.DRR");
	   lblHR.innerHTML = "No HR signal.";
	   if (appVibrate == false)
	   {
		   appVibrate = true;
		   navigator.vibrate(100);
	   }
   }
}