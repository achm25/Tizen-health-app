var currentFileName = "";
var gyroscopeFileName = "";
var gravityFileName = "";
var accelerationFileName = "";
var linear_accelerationFileName = "";
var hrmFileName= "";
function NewDoc(name){

	   var txtHeader = "timestamp,heartrate,rrinterval,calculatedrrinterval";
	   
	   var documentsDir;

	   
	   function onsuccess(files) {
//	     for(var i = 0; i < files.length; i++) {
//	       console.log("File Name is " + name + " //// " + files[i].name); // displays file name
//	     }
	     
//	     currentFileName = "HeartRate_" + n + ".txt";
	     var testFile = documentsDir.createFile(name);
//	     gyroscopeFileName = "gyroscope_" + n + ".txt";
//	     var gyroscopeFileName = documentsDir.createFile(gyroscopeFileName);
//	     gravityFileName = "gravity_" + n + ".txt";
//	     var gravityFileName = documentsDir.createFile(gravityFileName);
//	     accelerationFileName = "acceleration_" + n + ".txt";
//	     var accelerationFileName = documentsDir.createFile(accelerationFileName);
//	     linear_accelerationFileName = "linear_acceleration_" + n + ".txt";
//	     var linear_accelerationFileName = documentsDir.createFile(linear_accelerationFileName);
//	     hrmFileName = "hrm_" + n + ".txt";
//	     var hrmFileName = documentsDir.createFile(hrmFileName);
	     
	     if (testFile != null) {
	       testFile.openStream(
	         "w",
	         function(fs){
	           fs.write(txtHeader + "\r\n");
	           fs.close();
	         }, function(e){
	           console.log("Error " + e.message);
	         }, "UTF-8"
	       );
	       console.log("New file has been saved as " + currentFileName + " in Documents folder.");
	       //OpenDoc("NP_" + n + ".txt");
	     }
	   }

	   function onerror(error) {
	     console.log("The error " + error.message + " occurred when listing the files in the selected folder");
	   }

	   tizen.filesystem.resolve(
	     'documents', 
	     function(dir){
	       documentsDir = dir;
	       dir.listFiles(onsuccess, onerror);
	     }, function(e){
	       console.log("Error" + e.message);
	     }, "rw"
	   );
}

function AppendDoc(iFile, AppendText){
//	   var d = new Date();
//	   var n = d.getTime();
	   
	   var documentsDir;
	   function onsuccess(files) {
	     for(var i = 0; i < files.length; i++) {
	    	 if (files[i].name == iFile){
//	    		 console.log("File Name is " + files[i].name); // displays file name
	    	 var testFile = files[i];

		     if (testFile != null) {
		       testFile.openStream(
		         "a",
		         function(fs){
		           fs.write(AppendText + "\r\n");
		           fs.close();
		         }, function(e){
		           console.log("Error " + e.message);
		         }, "UTF-8"
		       );
		       //init();
		       //window.history.back();
		     }

	    	 }
	     }
	     
   	   }

	   function onerror(error) {
	     console.log("The error " + error.message + " occurred when listing the files in the selected folder");
	   }

	   tizen.filesystem.resolve(
	     'documents', 
	     function(dir){
	       documentsDir = dir;
	       dir.listFiles(onsuccess, onerror);
	     }, function(e){
	       console.log("Error" + e.message);
	     }, "rw"
	   );
}
